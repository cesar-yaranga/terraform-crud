import json
import boto3
import os

s3 = boto3.client('s3')
bucket_name = os.environ['BUCKET_NAME']
db_file = os.environ['DB_FILE']

def lambda_handler(event, context):
    method = event['httpMethod']
    
    if method == 'POST':
        return create_item(event)
    elif method == 'GET':
        return read_items()
    elif method == 'PUT':
        return update_item(event)
    elif method == 'DELETE':
        return delete_item(event)
    else:
        return {
            "statusCode": 405,
            "body": json.dumps({"message": "Method Not Allowed"})
        }

def read_items():
    try:
        response = s3.get_object(Bucket=bucket_name, Key=db_file)
        items = json.loads(response['Body'].read().decode('utf-8'))
        return {
            "statusCode": 200,
            "body": json.dumps(items)
        }
    except Exception as e:
        return {"statusCode": 500, "body": json.dumps(str(e))}

def create_item(event):
    try:
        new_item = json.loads(event['body'])
        response = s3.get_object(Bucket=bucket_name, Key=db_file)
        items = json.loads(response['Body'].read().decode('utf-8'))
        
        items['items'].append(new_item)
        s3.put_object(Bucket=bucket_name, Key=db_file, Body=json.dumps(items))
        
        return {
            "statusCode": 200,
            "body": json.dumps(new_item)
        }
    except Exception as e:
        return {"statusCode": 500, "body": json.dumps(str(e))}

def update_item(event):
    try:
        updated_item = json.loads(event['body'])
        response = s3.get_object(Bucket=bucket_name, Key=db_file)
        items = json.loads(response['Body'].read().decode('utf-8'))
        
        for i, item in enumerate(items['items']):
            if item['id'] == updated_item['id']:
                items['items'][i] = updated_item
                break
        
        s3.put_object(Bucket=bucket_name, Key=db_file, Body=json.dumps(items))
        return {
            "statusCode": 200,
            "body": json.dumps(updated_item)
        }
    except Exception as e:
        return {"statusCode": 500, "body": json.dumps(str(e))}

def delete_item(event):
    try:
        item_id = event['queryStringParameters']['id']
        response = s3.get_object(Bucket=bucket_name, Key=db_file)
        items = json.loads(response['Body'].read().decode('utf-8'))
        
        items['items'] = [item for item in items['items'] if item['id'] != item_id]
        
        s3.put_object(Bucket=bucket_name, Key=db_file, Body=json.dumps(items))
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "Item deleted"})
        }
    except Exception as e:
        return {"statusCode": 500, "body": json.dumps(str(e))}
